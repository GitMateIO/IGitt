"""
This package contains an abstraction for a git repository.
"""
