IGitt
=====

This is a simple library that allows you to access various git hosting
services like GitHub, GitLab and so on via one unified python interface.

Nice, huh?

What About the Name?
--------------------

This is an **I**\ nterface for **Git** hosting services. Igitt itself
comes from the german language and can be defined "an exclamation of
disgust in regards to an offensive odor, taste, sight, or thought".

Maintenance
-----------

IGitt is maintained by Lasse Schuirmann (lasse.schuirmann@gmail.com).
